Author: Gavin Atkin
Lab3 - CSCI 3453
Date: 11/20/2017

README:
* From CSE Grid terminal:
	-Extract the atk8013.tar.gz file.
	-Build source with: make makefile all
	-Run program with: ./memsim pagesize inputfilename outputfilename
	Where:
	pagesize is an integer value specifying the size of each frame.
	inputfilename is the file to read values from.
	outputfilename is the file to output results to.

* Output will be written to the outputfilename as well as to the console in table format.